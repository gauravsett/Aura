//
//  ViewController.swift
//  HelloWorld
//
//  Created by Aurelius Prochazka, revision history on Githbub.
//  Copyright © 2018 AudioKit. All rights reserved.
//


import AudioKit
import AudioKitUI
import Cocoa

var panCos: Double = -1
var panSin: Double = 1
var phaseShiftSin: Float = 0
var phaseShiftCos: Float = 1/4
var phaseShiftSquare: Float = 1/4
var ampCircle: Double = 1
var ampSquare: Double = 1
var DryWet: Double = 0

let cosine = AKTable(.sine, phase: Float(phaseShiftCos), count: 512)
let sin = AKTable(.sine, phase: Float(phaseShiftSin), count: 512)
let square = AKTable(.square, phase: Float(phaseShiftSquare), count: 512)
let cosquare = AKTable(.square, count: 512)

let note1 = AKOscillator(waveform: sin, amplitude: Double(ampCircle))
let note2 = AKOscillator(waveform: cosine, amplitude: Double(ampCircle))
let note3 = AKOscillator(waveform: square, amplitude: Double(ampSquare))
let note4 = AKOscillator(waveform: cosquare,amplitude: Double(ampSquare))
let leftPanSin = AKPanner(note1, pan: Double(panSin))
 let rightPanCos = AKPanner(note2, pan: Double(panCos))
 let leftPanSq = AKPanner(note3, pan: -1)
 let rightPanCsq = AKPanner(note4, pan: 1)

 let mixer = AKMixer(leftPanSin,rightPanCos,leftPanSq,rightPanCsq)
 let reverb = AKReverb(mixer, dryWetMix: Double(DryWet))


class ViewController: NSViewController, NSWindowDelegate {
    
   
    @IBOutlet private var circleAmp: NSSlider!
    @IBOutlet private var squareAmp: NSSlider!
    @IBOutlet private var wetDry: NSSlider!
    @IBOutlet private var phaseShift: NSSlider!
    
    @IBAction func getSliderValue(_ sender: NSSlider) {
        note1.amplitude = Double(circleAmp.floatValue)
        note2.amplitude = Double(circleAmp.floatValue)

    }
    @IBAction func getSliderValue1(_ sender: NSSlider) {
        note3.amplitude = Double(squareAmp.floatValue)
        note4.amplitude = Double(squareAmp.floatValue)
    }
    
    @IBAction func getSliderValue2(_ sender: Any) {
        reverb.dryWetMix = Double(wetDry.floatValue)
    }
    
    @IBAction func getSliderValue3(_ sender: Any) {
        cosine.phase = phaseShift.floatValue
        print(cosine.phase)
    }
    
        /*var circleFloat: Float {
            return circleSlider.floatValue
        }*/
    override func viewDidLoad() {
        super.viewDidLoad()
        circleAmp.floatValue = 1
        startPlaying()
    }
    override func viewDidAppear() {
        self.view.window?.title = "HelloOSC"
        self.view.window?.delegate = self
    }
    func windowShouldClose(_ sender: NSWindow) -> Bool {
        NSApplication.shared.terminate(self)
        return true
    }
    func startPlaying() {
        AudioKit.output = reverb
        do {
            try AudioKit.start()
        }
        catch {
            print("Audio Kit Didn't Start, Yaallll")
        }
        note1.start()
        note2.start()
        note3.start()
        note4.start()
    }
    
}


